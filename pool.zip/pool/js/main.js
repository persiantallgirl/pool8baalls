var WIDTH  = 1200,
    HEIGHT = 800;

// جهان سه بعدی
var renderer, scene, camera, game, controls, keyboard, lightsConfig, world, gui, eightballgame;
var debug = false; // اگر روشن باشد، فریم های برخوردش کشیده می شوند

var progressBar;

var stats = new Stats();
stats.setMode( 0 ); // 0: fps, 1: ms, 2: mb

var textureLoader = new THREE.TextureLoader();
THREE.DefaultLoadingManager.onProgress = function (item, loaded, total) {
  if (typeof progressBar !== 'undefined') {
    progressBar.style.width = (loaded / total * 100) + '%';
  }

  if (loaded == total && total > 7) {
    // پنهان كردن نوار پیشرفت
    var progBarDiv = document.getElementById('loading');
    progBarDiv.parentNode.removeChild(progBarDiv);

    gui.show(document.getElementById('mainMenu'));

    // عنصر DOM اجرا لوازم جانبی را ضمیمه کنید
    var canvasContainer = document.getElementById('canvas');
    canvasContainer.appendChild(renderer.domElement);
    draw();
  }
};

// برخی از ویژگی های دوربین را تنظیم کنید
var VIEW_ANGLE = 45,
    ASPECT     = WIDTH / HEIGHT,
    NEAR       = 1,
    FAR        = 1000;

// ما از ساعت برای اندازه گیری زمان، یک پسوند برای صفحه کلید استفاده می کنیم
var clock = new THREE.Clock();

function onLoad() {
  gui = new GameGui();

  progressBar = document.getElementById('prog-bar');

  // اجرایی WebGL، دوربین را ایجاد کنید
  // و یک صحنه
  camera = new THREE.PerspectiveCamera(VIEW_ANGLE, ASPECT, NEAR, FAR);
  camera.up = new THREE.Vector3(0,1,0);

  scene = new THREE.Scene();
  scene.add(camera);

  // ایجاد رندر
  renderer = new THREE.WebGLRenderer();
  renderer.setSize(WIDTH, HEIGHT);
  renderer.shadowMap.enabled = true;
  renderer.shadowMapSoft = true;

  // تنظیم world of your cannon.js برای فیزیک
  world = createPhysicsWorld();
  // جمعیت و فیزیک بدن:
  game = new Game();
  // تعریف کنید که چگونه اشیاء مختلف فیزیک را درک می کنند:
  setCollisionBehaviour();
  // نورپردازی را تنظیم کنید:
  addLights();

  // کنترل مویس
  controls = new THREE.OrbitControls(camera,renderer.domElement);

  controls.enableZoom = true;
  controls.enablePan = true;

  controls.minDistance = 35;
  controls.maxDistance = 165;
  // اجازه ندهید که دوربین به زیر زمین برود
  controls.maxPolarAngle = 0.49 * Math.PI;

  camera.position.set(-170, 70, 0);

  // پس زمینه رنگ سبز یشمی را عوض کنید.
  renderer.setClearColor(0x2727727, 1);
}

function createPhysicsWorld () {
  w = new CANNON.World();
  w.gravity.set(0, 30 * -9.82, 0); // m/s²

  w.solver.iterations = 10;
  // حل کننده نیروی
  //  برای استفاده از همه تکرارها
  w.solver.tolerance = 0;


  // اجازه وایسادن
  w.allowSleep = true;

  w.fixedTimeStep = 1.0 / 60.0; // seconds

  return w;
}

/** در اینجا تعامل زمانی که دو ماده لمس تعریف می شود تعریف می شود. به عنوان مثال. چقدر یک توپ
     هنگام برخورد با دیوار، انرژی را از دست می دهد.
    !TODO figure out whether the definition of Contactmaterials should be defined in
 جایی دیگر برای مثال شاید هر جسم توپ باید مواد تماس خود را با دیوارها تعریف کند.
*/
function setCollisionBehaviour() {
  world.defaultContactMaterial.friction = 0.1;
  world.defaultContactMaterial.restitution = 0.85;

  var ball_floor = new CANNON.ContactMaterial(
    Ball.contactMaterial,
    Table.floorContactMaterial,
    {friction: 0.7, restitution: 0.1}
  );

  var ball_wall = new CANNON.ContactMaterial(
    Ball.contactMaterial,
    Table.wallContactMaterial,
    {friction: 0.5, restitution: 0.9}
  );

  world.addContactMaterial(ball_floor);
  world.addContactMaterial(ball_wall);
}

function draw() {
  stats.begin();
  
  //کنترل
  controls.target.copy(game.balls[0].mesh.position);
  controls.update();

  // جهان فیزیک
  world.step(w.fixedTimeStep);

  // سه اشیاء
  var dt = clock.getDelta();
  game.tick(dt);

  stats.end();
  requestAnimationFrame(draw);
  renderer.render(scene, camera); //صحنه های ما را با دوربین ما ترسیم می کنیم
}

// نور محیط و دو نقطه نور بالا را بالای میز اضافه می کند
function addLights() {
  var light = new THREE.AmbientLight(0x0d0d0d); //نور محیط لطیف سفید
  scene.add(light);
  var tableLight1 = new TableLight( Table.LEN_X / 4, 150, 0);
  var tableLight2 = new TableLight(-Table.LEN_X / 4, 150, 0);
}
