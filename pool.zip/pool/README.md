# WebGL-Billiards
ThreeJS based 8-ball pool

Do check out our [Wiki]( https://github.com/jaks6/WebGL-Billiards/wiki )!

# [ Demo ]( http://jaks6.github.io/WebGL-Billiards/ )
